<?php
if(!empty($data))
{
	foreach($data as $row){		
	}
	?>	
	<p><?=$row->isi;?></p>
	<?php
}
?>